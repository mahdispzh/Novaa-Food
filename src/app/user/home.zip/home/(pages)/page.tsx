"use client";

import {
  AccountActions,
  CommentsCard,
  ProfileHeader,
  ProfileStats,
} from "@/src/app/user/home/_components/index";
import Main from "@/src/shared/ui/main/main";

const profileStats = [
  { label: "مکان ذخیره‌شده", value: "۴۵" },
  { label: "رویداد ذخیره‌شده", value: "۳۲" },
  { label: "دنبال‌کننده", value: "۹۶" },
];

export default function Page() {
  return (
    <Main hideFooter className="h-screen overflow-hidden bg-light-beige px-4 py-4 pb-4 text-[#3d332f]">
        <section className="mx-auto max-w-104 bg-light-beige">
          <ProfileHeader
            name={user.name}
            username={user.username}
            imageSrc={user.imageSrc}
            stats={[
              { label: "دنبال‌کننده", value: "120" },
              { label: "دنبال‌شونده", value: "45" },
              { label: "پست", value: "8" },
            ]}
          />
          <div className="px-4 pt-1">
            <ProfileStats stats={profileStats} />
            <CommentsCard />
          </div>
          <AccountActions />
        </section>
    </Main>
  );
}
