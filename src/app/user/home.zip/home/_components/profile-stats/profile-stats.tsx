interface ProfileStat {
  label: string;
  value: string;
}

interface ProfileStatsProps {
  stats: ProfileStat[];
}

export function ProfileStats({ stats }: ProfileStatsProps) {
  return (
    <div className="mt-1 flex gap-4 text-start">
      {stats.map((stat) => (
        <div key={stat.label} className="flex flex-col gap-0.5">
          <strong className="text-sm font-bold">{stat.value}</strong>
          <span className="text-[10px] text-gray-500">{stat.label}</span>
        </div>
      ))}
    </div>
  );
}