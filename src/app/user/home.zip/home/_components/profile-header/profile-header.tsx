import { ICONS } from "@/src/shared/constants/dynamic-icon";
import Image from "next/image";
import { ProfileStats } from "../profile-stats/profile-stats"; // adjust path to your actual file

interface ProfileStat {
  label: string;
  value: string;
}

interface ProfileHeaderProps {
  name: string;
  username: string;
  imageSrc?: string;
  stats: ProfileStat[];
}

export function ProfileHeader({
  name,
  username,
  imageSrc,
  stats,
}: ProfileHeaderProps) {
  return (
    <>
      <header className="flex items-center justify-start px-4 py-2">
        <button
          aria-label="بازگشت"
          className="flex h-10 w-10 items-center justify-center"
          type="button"
        >
          <ICONS.arrowRightIcon color="text-secondary" size="lg" />
        </button>
      </header>

      <div className="flex items-center gap-3 px-4 pt-1">
        <div className="relative h-25 w-25 shrink-0 overflow-hidden rounded-full">
          <Image
            fill
            priority
            alt={`${name} profile image`}
            className="object-cover"
            src={imageSrc}
          />
        </div>

        <div className="flex flex-1 flex-col gap-2">
          <h1 className="text-lg font-bold">{name}</h1>
          <p className="text-xs text-gray-500">{username}</p>
          <ProfileStats stats={stats} />
        </div>
      </div>
    </>
  );
}