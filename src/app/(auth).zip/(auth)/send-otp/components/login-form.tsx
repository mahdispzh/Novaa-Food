"use client";

import { ICONS } from "@/src/shared/constants/dynamic-icon";
import text from "@/src/shared/constants/texts/texts.json";
import { DefaultButton, Text } from "@/src/shared/ui";
import { Rules } from "@/src/shared/validations/rules";
import { useValidation } from "@/src/shared/validations/use-validation";
import { AuthHeroPanel } from "@/src/shared/components/auth/auth-hero-panel";

interface LoginFormProps {
  phone: string;
  changePhone: (value: string) => void;
  sendOtpAction: (phone: string) => void;
}

export default function LoginForm({
  phone,
  changePhone,
  sendOtpAction,
}: LoginFormProps) {
  const phoneValidation = useValidation(Rules.phone);

  const handlePhoneChange = (value: string) => {
    const numbersOnly = value.replace(/\D/g, "");

    phoneValidation.onChange(numbersOnly);
    changePhone(numbersOnly);
  };

  const handleSubmit = () => {
    const isValid = phoneValidation.validate();
    if (!isValid) return;

    sendOtpAction(phone);
  };

  return (
    <div className="flex h-screen w-screen flex-col overflow-hidden bg-white">
      <AuthHeroPanel
        description={text.dashboard.login.description}
        icon={<ICONS.phoneIcon color="text-white" size="4xl" />}
        title={text.dashboard.login.title}
      />

      {/* bottom form panel */}
      <div className="flex flex-1 flex-col justify-between bg-white px-8 pt-8 pb-8">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <div className="flex flex-row items-center gap-2">
              <input
                autoFocus
                className={`text-medium w-full border-b px-1 py-3 text-lg text-secondary transition outline-none placeholder:text-gray ${
                  phoneValidation.error
                    ? "border-danger focus:border-danger"
                    : "border-gray focus:border-primary"
                }`}
                dir="ltr"
                placeholder="Mobile Number"
                type="tel"
                value={phoneValidation.value}
                onChange={(e) => handlePhoneChange(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
              />
              <span className="border-b border-gray pb-3 text-lg text-secondary">
                98+
              </span>
            </div>

            {phoneValidation.error && (
              <span className="text-sm text-danger">
                {phoneValidation.error}
              </span>
            )}
          </div>
        </div>

        <div className="flex flex-col items-center gap-4">
          <DefaultButton
            action={handleSubmit}
            label={text.dashboard.login.submit}
            style="fill"
            type="primary"
            width="full"
          />

          <Text
            color="secondary"
            size="xs"
            text={text.dashboard.login.terms}
            weight="regular"
          />
        </div>
      </div>
    </div>
  );
}
