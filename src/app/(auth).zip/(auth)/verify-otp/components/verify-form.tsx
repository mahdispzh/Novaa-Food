"use client";

import { ICONS } from "@/src/shared/constants/dynamic-icon";
import text from "@/src/shared/constants/texts/texts.json";
import { DefaultButton, OtpInput, Text } from "@/src/shared/ui";
import { useRouter } from "next/navigation";
import { AuthHeroPanel } from "@/src/shared/components/auth/auth-hero-panel";

interface VerifyFormProps {
  code: string;
  onChangeCode: (value: string) => void;
  phoneNumber?: string;
  remainingTime?: string;
  isExpired?: boolean;
  resetTimer: () => void;
  verifyOtpAction: () => void;
  inputStatus: "default" | "success" | "error";
  isLoading?: boolean;
}

export default function VerifyForm({
  code,
  onChangeCode,
  phoneNumber = "********",
  remainingTime = "1:00",
  isExpired = false,
  resetTimer,
  verifyOtpAction,
  inputStatus,
  isLoading,
}: VerifyFormProps) {
  const router = useRouter();
  const isComplete = code.length === 4;

  return (
    <div className="flex h-screen w-screen flex-col overflow-hidden bg-white">
      <AuthHeroPanel
        description={`${text.dashboard.login.codeSent} ${phoneNumber} ${text.dashboard.login.sent}`}
        icon={<ICONS.checkbox color="text-white" size="4xl" />}
        title={text.dashboard.login.verifyCode}
      />

      {/* bottom form panel */}
      <div className="flex flex-1 flex-col justify-between bg-white px-8 pt-8 pb-8">
        <div className="flex flex-col items-center gap-6">
          <OtpInput
            length={4}
            value={code}
            onChange={onChangeCode}
            status={inputStatus}
            onEnter={() => {
              if (isComplete && !isLoading) {
                verifyOtpAction();
              }
            }}
          />

          <div className="flex flex-col items-center gap-2">
            {!isExpired && (
              <Text
                color="secondary"
                size="xs"
                text={text.dashboard.login.remainingTime}
                weight="regular"
              />
            )}

            {isExpired ? (
              <button className="cursor-pointer" onClick={resetTimer}>
                <Text
                  className="underline"
                  color="secondary"
                  size="md"
                  text={text.dashboard.login.resendCode}
                  weight="medium"
                />
              </button>
            ) : (
              <Text color="secondary" size="lg" text={remainingTime} weight="bold" />
            )}
          </div>
        </div>

        <div className="flex flex-col items-center gap-4">
          <DefaultButton
            action={verifyOtpAction}
            disabled={!isComplete || isLoading}
            label={text.dashboard.login.submit}
            style="fill"
            type="primary"
            width="full"
          />

          <button
            className="cursor-pointer"
            onClick={() => router.push("/send-otp")}
          >
            <Text
              color="secondary"
              size="sm"
              text="تغییر شماره و دریافت مجدد کد"
              weight="regular"
            />
          </button>
        </div>
      </div>
    </div>
  );
}
