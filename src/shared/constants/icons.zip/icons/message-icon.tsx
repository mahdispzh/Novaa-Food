import type { IconProps } from "@/src/shared/types/IconTypes";
import { ICON_SIZE_CLASS } from "../icon-sizes";

export function MessageIcon({
  size = "lg",
  color = "text-primary",
}: IconProps) {
  return (
    <svg
      className={`${ICON_SIZE_CLASS[size]} ${color}`}
      fill="none"
      height="15"
      viewBox="0 0 15 15"
      width="15"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clipPath="url(#clip0_548_1910)">
        <path
          clipRule="evenodd"
          d="M7.5 12.1875C6.9525 12.1875 6.42375 12.1237 5.91563 12.0155L3.70875 13.342L3.73828 11.1675C2.04656 10.1503 0.9375 8.46844 0.9375 6.5625C0.9375 3.45609 3.87563 0.9375 7.5 0.9375C11.1244 0.9375 14.0625 3.45609 14.0625 6.5625C14.0625 9.66937 11.1244 12.1875 7.5 12.1875ZM7.5 0C3.35812 0 0 2.93859 0 6.5625C0 8.63391 1.09922 10.4784 2.8125 11.6808V15L6.09797 13.0064C6.55266 13.0814 7.02047 13.125 7.5 13.125C11.6419 13.125 15 10.1869 15 6.5625C15 2.93859 11.6419 0 7.5 0Z"
          fill="currentColor"
          fillRule="evenodd"
        />
      </g>
      <defs>
        <clipPath id="clip0_548_1910">
          <rect fill="white" height="15" width="15" />
        </clipPath>
      </defs>
    </svg>
  );
}
